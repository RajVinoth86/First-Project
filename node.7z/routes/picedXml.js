// const express = require('express');
// const router = express.Router();
// const convert = require('xml-js');
// const xmlfile = require('fs');
// const file = xmlfile.readFileSync('project.xml', 'utf8');
// // const app = express();
// // app.use(bodyParser.json());

// var xmlToJson = convert.xml2json(file, {compact: false, spaces: 4});
// // export default class PicedXml{
// //     getXmlData(){
// //         router.get('/',function(req,res){
// //             res.send(xmlToJson);
// //         });
// //     }
// // }
// router.get('/getXmlData', function(req, res,next){
//     res.send(xmlToJson);
// });

// module.exports = router;



