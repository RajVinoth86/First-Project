const express = require('express');

const router = express.Router();

const convert = require('xml-js');

const xmlfile = require('fs');
const http = require("http");




const port = 5000;



const app = express();
const server = http.createServer(app);

app.use(

  express.urlencoded({

    extended: true

  })

)



app.use(express.json());

app.use(function (req, res, next){

  // Website you wish to allow to connect

 res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');



 // Request methods you wish to allow

 res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');



 // Request headers you wish to allow

 res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');



 // Set to true if you need the website to include cookies in the requests sent

 // to the API (e.g. in case you use sessions)

 res.setHeader('Access-Control-Allow-Credentials', true);



 // Pass to next layer of middleware

 next();

});




app.get('/appConfig',(req,res) => {

    var file = xmlfile.readFileSync('project.xml', 'utf8');

    var xmlTojson = convert.xml2json(file, {compact: false});

    var compactJson = convert.xml2json(file, {compact: true});

    res.send(

      {

        sucess: true,

        result: JSON.parse(xmlTojson),

        compactJson: JSON.parse(compactJson)

      } 

    );

})



app.post('/updateAppConfig', function(req,res){

    var jsontoxml= convert.js2xml(req.body, { compact: true, spaces: 2 });

    xmlfile.writeFile("project.xml", jsontoxml, function(err, data) {

      if (err) console.log(err);



      res.send(

        {

          sucess: true,

          message: "successfully updated"

        } 

      );

    });

});



server.listen(port, () => console.log(`Listening on port ${port}`));