const express = require("express");
const router = express.Router();
const fs = require('fs');

router.get('/getFavorites', (req, res) => {
   fs.readFile('./config/favorites.js', function(err, data) { 
      if (err) throw err;  
      res.send(
        {
          sucess: true,
          data: JSON.parse(data),
        } 
      );
     });
    
});

router.post('/addFavorites', (req, res) => {
    var favorites= JSON.stringify(req.body);
    console.log(req.body);
    fs.writeFile("./config/favorites.js", favorites, function(err, data) {
      if (err) console.log(err);

      res.send(
        {
          sucess: true,
          message: "successfully updated"
        } 
      );
    });
});

module.exports = router;



