const express = require('express');
const cors = require('cors')
const http = require("http");
const socketIo = require("socket.io");


const socket = require("./routes/socket");
const picedXmlRoute = require("./routes/picedXml");
const fevoritesRoute = require("./routes/favorites")

const port = 5000;

const app = express();
app.use(cors())
app.use(
  express.urlencoded({
    extended: true
  })
)

app.use(express.json());
app.use("/nodeSocket", socket);
app.use("/picedXml", picedXmlRoute);
app.use("/favorites", fevoritesRoute);

const server = http.createServer(app);
options={
  cors:true,
  origins:["http://localhost:3000"],
 }
const io = socketIo(server,options);

let interval;

io.on("connection", (socket) => {
  console.log("New client connected");
  if (interval) {
    clearInterval(interval);
  }
  interval = setInterval(() => getApiAndEmit(socket), 1000);
  socket.on("disconnect", () => {
    console.log("Client disconnected");
    clearInterval(interval);
  });
});


const getApiAndEmit = socket => {
  const response = new Date();
  // Emitting a new message. Will be consumed by the client
  socket.emit("FromAPI", response);
};

server.listen(port, () => console.log(`Listening on port ${port}`));